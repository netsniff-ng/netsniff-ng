#!/bin/sh
#
# More stuff: man netsniff-ng
#
#  Start sniffing in verbose mode on device wlan0
#

netsniff-ng -d wlan0

